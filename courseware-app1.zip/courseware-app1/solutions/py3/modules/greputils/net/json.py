def grep_json():
    return 'Calling grep_json'

# Copyright 2015-2018 Aaron Maxwell. All rights reserved.
