def grep_html():
    return 'Calling grep_html'

def grep_html_as_text():
    return 'Calling grep_html_as_text'

# Copyright 2015-2018 Aaron Maxwell. All rights reserved.
