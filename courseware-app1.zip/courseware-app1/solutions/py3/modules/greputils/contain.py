def contains():
    return 'Calling contains'

def containsi():
    return 'Calling containsi'

# Copyright 2015-2018 Aaron Maxwell. All rights reserved.
