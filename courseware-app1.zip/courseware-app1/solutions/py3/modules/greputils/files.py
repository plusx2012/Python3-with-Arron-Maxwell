def grepfile():
    return 'Calling grepfile'

def grepfilei():
    return 'Calling grepfilei'

# Copyright 2015-2018 Aaron Maxwell. All rights reserved.
