from .files import (
    grepfile,
    grepfilei,
)

from .contain import (
    contains,
    containsi,
)

from .net import (
    grep_html,
    grep_html_as_text,
    grep_text,
    grep_json,
)

# Copyright 2015-2018 Aaron Maxwell. All rights reserved.
