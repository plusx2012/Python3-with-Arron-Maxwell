Here are the lab practice files for Aaron Maxwell's Python classes for
O'Reilly/Safari. Information here: https://powerfulpython.com/labs/

In the "labs" folder, you'll see "py2" or "py3". If the course you are
taking only supports Python 3, look inside py3; otherwise choose
whichever version of Python you want to use for this course.

Inside, you'll see helloworld.py, and helloworld_extra.py. Do both
labs, in this order. (Exception: If you are taking the "Pythonic OOP"
class, you only need to do helloworld.py.)

When you are done, or if you have trouble and need a hint, look in the
solutions folder and compare to what you wrote.

That's it! See you in class.

Cheers,
Aaron
